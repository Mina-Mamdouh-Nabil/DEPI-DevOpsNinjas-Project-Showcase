
import React, { useState } from 'react';

const Logo = () => (
  <div className="flex items-center gap-2">
    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm0 18c-4.411 0-8-3.589-8-8s3.589-8 8-8 8 3.589 8 8-3.589 8-8 8z" fill="url(#logoGradient)"/>
      <path d="M15.414 13.586a2 2 0 1 0-2.828-2.828 2 2 0 0 0 2.828 2.828zM8.586 13.586a2 2 0 1 0-2.828-2.828 2 2 0 0 0 2.828 2.828zM12 17a5 5 0 0 1-5-5h2a3 3 0 0 0 6 0h2a5 5 0 0 1-5 5z" fill="url(#logoGradient)"/>
      <defs>
        <linearGradient id="logoGradient" x1="2" y1="12" x2="22" y2="12" gradientUnits="userSpaceOnUse">
          <stop stopColor="#22d3ee"/>
          <stop offset="1" stopColor="#38bdf8"/>
        </linearGradient>
      </defs>
    </svg>
    <span className="text-xl font-bold text-white">DevOps Command Hub</span>
  </div>
);

const navLinks = [
  { name: 'About', href: '#about' },
  { name: 'Features', href: '#features' },
  { name: 'Architecture', href: '#architecture' },
  { name: 'Team', href: '#team' },
  { name: 'Feedback', href: '#feedback' },
];

export const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };
  
  const closeMenu = () => {
    setIsMenuOpen(false);
  }

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-slate-900/80 backdrop-blur-sm border-b border-slate-800">
      <div className="container mx-auto px-6 py-3 flex justify-between items-center">
        <a href="#home" aria-label="Home" onClick={closeMenu}>
          <Logo />
        </a>
        <nav className="hidden md:flex space-x-6">
          {navLinks.map(link => (
            <a key={link.name} href={link.href} className="text-slate-300 hover:text-cyan-400 transition-colors">
              {link.name}
            </a>
          ))}
        </nav>
        {/* Mobile Menu Button */}
        <div className="md:hidden">
          <button onClick={toggleMenu} aria-label="Toggle menu" className="text-slate-300 focus:outline-none z-50">
            {isMenuOpen ? (
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
            ) : (
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" /></svg>
            )}
          </button>
        </div>
      </div>
      
      {/* Mobile Menu */}
      <div className={`md:hidden absolute top-0 left-0 w-full h-screen bg-slate-900/95 backdrop-blur-sm transition-transform duration-300 ease-in-out ${isMenuOpen ? 'transform-none' : '-translate-y-full'}`}>
        <nav className="flex flex-col items-center justify-center h-full space-y-6">
          {navLinks.map(link => (
            <a key={link.name} href={link.href} onClick={closeMenu} className="text-2xl text-slate-200 hover:text-cyan-400 transition-colors">
              {link.name}
            </a>
          ))}
        </nav>
      </div>
    </header>
  );
};

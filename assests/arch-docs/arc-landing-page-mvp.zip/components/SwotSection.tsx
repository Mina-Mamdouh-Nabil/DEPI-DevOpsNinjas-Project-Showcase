
import React from 'react';

const swotData = {
  strengths: ["Unified hub", "AI insights", "Self-healing capabilities", "Strong portfolio showcase"],
  weaknesses: ["Complex to set up", "AI quality can vary", "Infrastructure heavy"],
  opportunities: ["Extensible for companies (CSR/KTP)", "Great fit for internships", "Builds industry-ready skills"],
  threats: ["Cloud provider quotas", "Compliance limitations", "Security risks if misconfigured"],
};

const SwotCard: React.FC<{ title: string; items: string[]; color: string; }> = ({ title, items, color }) => (
  <div className={`p-6 rounded-lg bg-slate-800/50 border-t-4 ${color}`}>
    <h3 className="text-2xl font-bold text-white mb-4">{title}</h3>
    <ul className="space-y-2 list-disc list-inside text-slate-400">
      {items.map((item, index) => <li key={index}>{item}</li>)}
    </ul>
  </div>
);

export const SwotSection: React.FC = () => {
  return (
    <section id="swot" className="py-20 bg-slate-900/50">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-4xl mx-auto mb-12">
          <h2 className="text-4xl font-bold text-white mb-4">SWOT Analysis</h2>
          <p className="text-lg text-slate-300">
            A strategic look at our project's position, potential, and challenges.
          </p>
        </div>
        <div className="grid md:grid-cols-2 gap-8">
          <SwotCard title="Strengths" items={swotData.strengths} color="border-green-500" />
          <SwotCard title="Weaknesses" items={swotData.weaknesses} color="border-yellow-500" />
          <SwotCard title="Opportunities" items={swotData.opportunities} color="border-blue-500" />
          <SwotCard title="Threats" items={swotData.threats} color="border-red-500" />
        </div>
      </div>
    </section>
  );
};

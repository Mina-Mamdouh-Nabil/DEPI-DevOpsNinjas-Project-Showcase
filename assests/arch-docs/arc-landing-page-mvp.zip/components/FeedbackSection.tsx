import React from 'react';

export const FeedbackSection: React.FC = () => {
  return (
    <section id="feedback" className="py-20 bg-slate-900">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold text-white mb-4">Share Your Feedback</h2>
          <p className="text-lg text-slate-300 mb-8">
            Have an idea or a comment about our project? We'd love to hear from you. Click the button below to open the feedback form in a new tab.
          </p>
          <a
            href="https://docs.google.com/forms/d/e/1FAIpQLSe1Xf9aJZZiYLVcv3OZSnC6Vv88V6C-baDgTWWWIE-bbSgbnQ/viewform?usp=header"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block px-10 py-3 bg-cyan-500 text-white font-bold rounded-lg shadow-lg hover:bg-cyan-600 focus:outline-none focus:ring-2 focus:ring-cyan-400 focus:ring-opacity-75 transition-transform transform hover:scale-105"
          >
            Open Feedback Form
          </a>
        </div>
      </div>
    </section>
  );
};

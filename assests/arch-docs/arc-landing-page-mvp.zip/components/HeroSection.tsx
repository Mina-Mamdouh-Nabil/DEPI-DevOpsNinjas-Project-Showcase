
import React from 'react';
import { WalkingRobot } from './WalkingRobot';

// New AI Agent Background Component
const AiAgentBackground = () => (
  <div className="absolute inset-0 z-0 overflow-hidden bg-slate-900">
    {/* SVG for the AI agent/robot eye */}
    <svg className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[90vw] h-[90vh] md:w-[60vw] md:h-[60vh] text-cyan-500/10" viewBox="0 0 400 400" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Outer rings */}
      <circle cx="200" cy="200" r="190" stroke="currentColor" strokeWidth="0.5" />
      <circle cx="200" cy="200" r="160" stroke="currentColor" strokeWidth="0.5" style={{ animation: `spin 40s linear infinite reverse` }} />
      <circle cx="200" cy="200" r="130" stroke="currentColor" strokeWidth="0.5" style={{ animation: `spin 35s linear infinite` }} />

      {/* Central eye */}
      <circle cx="200" cy="200" r="70" fill="currentColor" className="opacity-10" />
      <circle cx="200" cy="200" r="60" stroke="url(#eyeGradient)" strokeWidth="1.5" />
      <circle cx="200" cy="200" r="25" fill="url(#eyeGradient)" style={{ animation: `pulse 4s ease-in-out infinite` }} />
      
      {/* Data streams */}
      <path d="M 50 100 A 150 150 0 0 1 350 100" stroke="currentColor" strokeWidth="0.5" strokeDasharray="4 8" style={{ animation: `animate-dash 10s linear infinite` }} />
      <path d="M 50 300 A 150 150 0 0 0 350 300" stroke="currentColor" strokeWidth="0.5" strokeDasharray="4 8" style={{ animation: `animate-dash-reverse 10s linear infinite` }} />
      <path d="M 100 50 A 150 150 0 0 1 100 350" stroke="currentColor" strokeWidth="0.5" strokeDasharray="2 6" style={{ animation: `animate-dash 8s linear infinite` }} />
      <path d="M 300 50 A 150 150 0 0 0 300 350" stroke="currentColor" strokeWidth="0.5" strokeDasharray="2 6" style={{ animation: `animate-dash-reverse 8s linear infinite` }} />
      
      {/* Particle Lights */}
      <g>
        {[...Array(50)].map((_, i) => {
          const angle = Math.random() * 2 * Math.PI;
          const radius = 190;
          const endX = 200 + radius * Math.cos(angle);
          const endY = 200 + radius * Math.sin(angle);
          const duration = Math.random() * 5 + 5;
          const delay = Math.random() * 5;
          return (
            <circle key={i} r={Math.random() * 1.5} fill="#22d3ee" opacity="0">
              <animateMotion
                path={`M200,200 L${endX},${endY}`}
                dur={`${duration}s`}
                begin={`${delay}s`}
                repeatCount="indefinite"
              />
              <animate attributeName="opacity" values="0; 1; 1; 0" keyTimes="0; 0.1; 0.9; 1" dur={`${duration}s`} begin={`${delay}s`} repeatCount="indefinite" />
            </circle>
          );
        })}
      </g>
      
      <defs>
        <radialGradient id="eyeGradient" cx="0.5" cy="0.5" r="0.5">
          <stop offset="0%" stopColor="#22d3ee" />
          <stop offset="100%" stopColor="#38bdf8" stopOpacity="0" />
        </radialGradient>
      </defs>
    </svg>

    <div className="absolute inset-0 bg-slate-900 [mask-image:radial-gradient(ellipse_at_center,transparent_30%,black)]"></div>

    <style>{`
      @keyframes spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
      }
      @keyframes pulse {
        0%, 100% { transform: scale(1); opacity: 1; }
        50% { transform: scale(1.2); opacity: 0.7; }
      }
      @keyframes animate-dash {
        to { stroke-dashoffset: -100; }
      }
      @keyframes animate-dash-reverse {
        to { stroke-dashoffset: 100; }
      }
      svg { transform-origin: center; }
    `}</style>
  </div>
);

export const HeroSection: React.FC = () => {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      <AiAgentBackground />
      
      <div className="relative z-10 container mx-auto px-6 text-center">
        <h1 className="text-5xl md:text-7xl font-bold text-white leading-tight tracking-tight">
          DevOps Command Hub
        </h1>
        <p className="mt-6 max-w-4xl mx-auto text-lg md:text-xl text-cyan-200/90">
          Unified Observability, Self-Healing, Incident Command, AI Log Analysis, and DevSecOps Security Insights
        </p>
        <div className="mt-10 flex items-center justify-center gap-4">
          <a
            href="https://github.com/AhmedAlhusaini/DEPI-DevOpsNinjas-Project-Showcase"
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto px-8 py-3 bg-cyan-500 text-white font-semibold rounded-lg shadow-lg hover:bg-cyan-600 focus:outline-none focus:ring-2 focus:ring-cyan-400 focus:ring-opacity-75 transition-transform transform hover:scale-105"
          >
            View GitHub Repo
          </a>
        </div>
      </div>
      <WalkingRobot />
    </section>
  );
};

import React from 'react';

const techCategories = [
  { name: "Frontend", items: ["React"] },
  { name: "Backend", items: ["FastAPI (Python)"] },
  { name: "Workers", items: ["Celery", "RQ"] },
  { name: "IaC", items: ["Terraform", "Helm"] },
  { name: "Runtime", items: ["Docker", "Kubernetes (K3s/AKS/EKS/GKE)"] },
  { name: "Observability", items: ["Prometheus", "Grafana", "Loki/ELK", "Alertmanager", "OpenTelemetry"] },
  { name: "Runbook Engine", items: ["Ansible AWX", "Rundeck"] },
  { name: "AI Layer", items: ["Ollama (local)", "Azure OpenAI"] },
  { name: "DevSecOps", items: ["Sigma/YARA", "Trivy"] },
];

export const TechStackSection: React.FC = () => {
  return (
    <section id="tech-stack" className="py-20 bg-slate-900">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-4xl mx-auto mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">Our Tech Stack Roadmap</h2>
          <p className="text-lg text-slate-300">
            Built with modern, scalable, and industry-standard technologies to deliver a robust and reliable platform.
          </p>
        </div>
        <div className="flex flex-col items-center gap-8">
          {techCategories.map((category, index) => (
            <div 
              key={category.name} 
              className={`w-full md:w-3/4 lg:w-1/2 bg-slate-800/50 p-6 rounded-lg border border-slate-700 shadow-lg transition-transform duration-300 hover:scale-105 hover:border-cyan-500 ${index % 2 === 0 ? 'md:self-start' : 'md:self-end'}`}
            >
              <h3 className="text-xl font-bold text-cyan-400 mb-4">{category.name}</h3>
              <div className="flex flex-wrap gap-2">
                {category.items.map(item => (
                  <span key={item} className="bg-slate-700 text-slate-200 px-3 py-1 rounded-full text-sm font-medium">
                    {item}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

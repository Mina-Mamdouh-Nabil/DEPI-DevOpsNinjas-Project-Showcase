
import React from 'react';

const teamMembers = [
  { name: "Ahmed Tarek Alhusainy", role: "Team Leader", imgId: "1" },
  { name: "Lamiaa El-sherif", role: "DevOps Engineer", imgId: "2" },
  { name: "Mohamed Sherif", role: "DevOps Engineer", imgId: "3" },
  { name: "Mohamed Reda", role: "DevOps Engineer", imgId: "4" },
  { name: "Mina Mamdouh", role: "DevOps Engineer", imgId: "5" },
];

const TeamMemberCard: React.FC<{ name: string; role: string; imgId: string }> = ({ name, role, imgId }) => (
  <div className="text-center">
    <img
      src={`https://picsum.photos/seed/${imgId}/200`}
      alt={name}
      className="w-32 h-32 mx-auto rounded-full border-4 border-slate-700 shadow-lg mb-4 transition-transform duration-300 hover:scale-110 hover:border-cyan-500"
    />
    <h4 className="text-xl font-bold text-white">{name}</h4>
    <p className="text-cyan-400">{role}</p>
  </div>
);


export const TeamSection: React.FC = () => {
  return (
    <section id="team" className="py-20 bg-slate-900">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-4xl mx-auto mb-12">
          <h2 className="text-4xl font-bold text-white mb-4">Our Team</h2>
          <h3 className="text-2xl font-semibold text-cyan-400 mb-2">DEPI DevOps Ninjas</h3>
          <p className="text-lg text-slate-300">
            Driven by passion and hard work, our team is dedicated to creating solutions that make a real impact in the world of software development and operations.
          </p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-10">
          {teamMembers.map(member => (
            <TeamMemberCard key={member.name} {...member} />
          ))}
        </div>
      </div>
    </section>
  );
};

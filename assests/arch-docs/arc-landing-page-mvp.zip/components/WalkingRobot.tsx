
import React, { useState, useEffect } from 'react';

export const WalkingRobot: React.FC = () => {
  const [position, setPosition] = useState({ x: 50, y: 85 }); // Initial position in %

  useEffect(() => {
    const moveRobot = () => {
      // Bounding box as percentage of parent (Hero section)
      const minX = 10;
      const maxX = 90;
      const minY = 70; // Keep it in lower part of the screen
      const maxY = 90;

      const newX = Math.random() * (maxX - minX) + minX;
      const newY = Math.random() * (maxY - minY) + minY;
      setPosition({ x: newX, y: newY });
    };

    const intervalId = setInterval(moveRobot, 5100); // Interval slightly longer than transition
    setTimeout(moveRobot, 100); // Initial move

    return () => clearInterval(intervalId);
  }, []); // Run only once on mount

  return (
    <>
      <style>{`
        .robot-body {
            animation: bob 1s ease-in-out infinite;
        }
        
        @keyframes bob {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-3px); }
        }
        
        .left-leg { animation: walk-leg-1 1s linear infinite; transform-origin: top; }
        .right-leg { animation: walk-leg-2 1s linear infinite; transform-origin: top; }

        @keyframes walk-leg-1 {
          0%, 100% { transform: rotate(20deg); }
          50% { transform: rotate(-20deg); }
        }
        @keyframes walk-leg-2 {
          0%, 100% { transform: rotate(-20deg); }
          50% { transform: rotate(20deg); }
        }
        
        .eye-scan {
            animation: scan 3s linear infinite;
        }
        
        @keyframes scan {
            0%, 100% { transform: translateX(-3px); }
            50% { transform: translateX(3px); }
        }
        
        .log-text {
            animation: scroll-logs 8s linear infinite;
            will-change: transform;
        }
        
        @keyframes scroll-logs {
            from { transform: translateY(0); }
            to { transform: translateY(-50%); }
        }
      `}</style>
      <div 
        className="absolute w-48 h-48 z-40 pointer-events-none" 
        aria-hidden="true"
        style={{
          left: `${position.x}%`,
          top: `${position.y}%`,
          transform: 'translate(-50%, -50%)',
          transition: 'left 5s linear, top 5s linear'
        }}
      >
        <div className="relative w-full h-full">
            {/* Magnifier and Log File */}
            <div className="absolute top-[30px] left-[110px] w-[90px] h-[90px]">
                {/* Magnifier */}
                <svg viewBox="0 0 100 100" className="absolute w-full h-full text-slate-500 drop-shadow-lg">
                    <circle cx="40" cy="40" r="35" fill="rgba(22, 78, 99, 0.3)" stroke="currentColor" strokeWidth="5"/>
                    <line x1="65" y1="65" x2="95" y2="95" stroke="currentColor" strokeWidth="10" strokeLinecap="round"/>
                </svg>
                 {/* Log File */}
                <div className="absolute top-[18px] left-[18px] w-[44px] h-[44px] rounded-full overflow-hidden">
                    <div className="w-full h-full bg-slate-800 text-cyan-300 text-[5px] font-mono leading-tight whitespace-nowrap p-1">
                        <div className="log-text">
                            <p>[INFO] Initializing service...</p>
                            <p>[DEBUG] Configuration loaded.</p>
                            <p>[WARN] Deprecated API in use.</p>
                            <p>[INFO] Request received: GET /api/v1</p>
                            <p>[ERROR] Null pointer at line 42.</p>
                            <p>[INFO] Retrying connection...</p>
                            <p>[DEBUG] Cache hit for user:123.</p>
                            <p>[INFO] Process complete.</p>
                            {/* Duplicate for seamless scroll */}
                            <p>[INFO] Initializing service...</p>
                            <p>[DEBUG] Configuration loaded.</p>
                            <p>[WARN] Deprecated API in use.</p>
                            <p>[INFO] Request received: GET /api/v1</p>
                            <p>[ERROR] Null pointer at line 42.</p>
                            <p>[INFO] Retrying connection...</p>
                            <p>[DEBUG] Cache hit for user:123.</p>
                            <p>[INFO] Process complete.</p>
                        </div>
                    </div>
                </div>
            </div>

            {/* Robot */}
            <svg viewBox="0 0 150 150" className="absolute w-full h-full">
                <g className="robot-body">
                    {/* Legs */}
                    <rect x="70" y="105" width="8" height="30" rx="4" fill="#64748b" className="right-leg" />
                    <rect x="52" y="105" width="8" height="30" rx="4" fill="#94a3b8" className="left-leg" />
                    
                    {/* Body */}
                    <rect x="40" y="70" width="50" height="40" rx="10" fill="#475569" />
                    <rect x="45" y="75" width="40" height="30" rx="5" fill="#334155" />

                    {/* Head */}
                    <rect x="45" y="40" width="40" height="35" rx="8" fill="#475569" />
                    {/* Eye */}
                    <rect x="50" y="47.5" width="30" height="15" rx="5" fill="#1e293b" />
                    <rect x="62" y="51.5" width="6" height="7" rx="2" fill="#22d3ee" className="eye-scan"/>

                     {/* Arm */}
                    <rect x="85" y="80" width="40" height="8" rx="4" fill="#64748b" transform="rotate(20 85 84)" />
                </g>
            </svg>
        </div>
      </div>
    </>
  );
};
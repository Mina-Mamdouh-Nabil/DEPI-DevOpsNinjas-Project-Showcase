
import React from 'react';

export const CtaSection: React.FC = () => {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real application, you would handle form submission here.
    alert('Collaboration request sent! (This is a demo)');
  };
  
  return (
    <section id="collaborate" className="py-20 bg-slate-900/50">
      <div className="container mx-auto px-6">
        <div className="bg-slate-800/50 border border-slate-700 p-8 md:p-12 rounded-lg shadow-2xl text-center">
          <h2 className="text-4xl font-bold text-white mb-4">Ready to Collaborate?</h2>
          <p className="text-lg max-w-3xl mx-auto mb-8 text-slate-300">
            We invite companies to try the DevOps Command Hub. Fill out the form below to get in touch with our team. We can deploy our solution or help extend your company's current systems.
          </p>
          <form onSubmit={handleSubmit} className="max-w-xl mx-auto text-left space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-slate-300 mb-1">Full Name</label>
                <input type="text" id="name" name="name" required className="w-full bg-slate-700/50 border border-slate-600 rounded-md py-2 px-3 text-white focus:ring-cyan-500 focus:border-cyan-500 transition" placeholder="Your Name" />
              </div>
              <div>
                <label htmlFor="company" className="block text-sm font-medium text-slate-300 mb-1">Company</label>
                <input type="text" id="company" name="company" className="w-full bg-slate-700/50 border border-slate-600 rounded-md py-2 px-3 text-white focus:ring-cyan-500 focus:border-cyan-500 transition" placeholder="Your Company" />
              </div>
            </div>
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-slate-300 mb-1">Email Address</label>
              <input type="email" id="email" name="email" required className="w-full bg-slate-700/50 border border-slate-600 rounded-md py-2 px-3 text-white focus:ring-cyan-500 focus:border-cyan-500 transition" placeholder="you@company.com" />
            </div>
            <div>
              <label htmlFor="message" className="block text-sm font-medium text-slate-300 mb-1">Message</label>
              <textarea id="message" name="message" rows={4} required className="w-full bg-slate-700/50 border border-slate-600 rounded-md py-2 px-3 text-white focus:ring-cyan-500 focus:border-cyan-500 transition" placeholder="Tell us how we can collaborate..."></textarea>
            </div>
            <div className="text-center pt-4">
              <button
                type="submit"
                className="inline-block px-10 py-3 bg-cyan-500 text-white font-bold rounded-lg shadow-lg hover:bg-cyan-600 focus:outline-none focus:ring-2 focus:ring-cyan-400 focus:ring-opacity-75 transition-transform transform hover:scale-105"
              >
                Send Collaboration Request
              </button>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
};
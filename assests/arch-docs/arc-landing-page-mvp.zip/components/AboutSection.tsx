
import React from 'react';

const InfinityIcon = () => (
  <svg viewBox="0 0 200 100" className="w-full max-w-lg mx-auto" xmlns="http://www.w3.org/2000/svg">
    <path d="M50 50 C 0 0, 100 0, 100 50 S 200 100, 150 50 S 100 0, 50 50" fill="none" stroke="url(#infinityGradient)" strokeWidth="4" />
    <defs>
      <linearGradient id="infinityGradient" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" stopColor="#22d3ee" />
        <stop offset="50%" stopColor="#38bdf8" />
        <stop offset="100%" stopColor="#6366f1" />
      </linearGradient>
    </defs>
    <text x="18" y="32" fontSize="8" fill="#e2e8f0">Plan</text>
    <text x="8" y="68" fontSize="8" fill="#e2e8f0">Code</text>
    <text x="35" y="86" fontSize="8" fill="#e2e8f0">Build</text>
    <text x="70" y="80" fontSize="8" fill="#e2e8f0">Test</text>
    
    <text x="90" y="10" fontSize="8" fill="#e2e8f0">Deploy</text>
    <text x="155" y="16" fontSize="8" fill="#e2e8f0">Operate</text>
    <text x="155" y="50" fontSize="8" fill="#e2e8f0">Monitor</text>
    <text x="120" y="80" fontSize="8" fill="#e2e8f0">Feedback</text>
  </svg>
);

export const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-slate-900/50">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold text-white mb-4">About the Project</h2>
          <p className="text-lg text-slate-300 mb-8">
            A unified DevOps hub that covers the full infinity loop from planning and coding to monitoring and feedback. Our platform integrates the power of <span className="text-cyan-400 font-semibold">DevOps</span>, the intelligence of <span className="text-blue-400 font-semibold">AI</span>, and the security of <span className="text-green-400 font-semibold">DevSecOps</span> into a single, cohesive command center.
          </p>
        </div>
        <div className="mt-12">
          <InfinityIcon />
        </div>
      </div>
    </section>
  );
};

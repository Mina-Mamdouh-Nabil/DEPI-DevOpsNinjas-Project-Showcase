
import React from 'react';

const milestones = [
  { id: "M0", title: "Bootstrap", description: "Repo, K3s cluster, and sample app setup." },
  { id: "M1", title: "Observability Base", description: "Integrated Prometheus, Grafana, and Loki." },
  { id: "M2", title: "Logs & AI", description: "Log pipeline, AI analyzer, and DevSecOps lens." },
  { id: "M3", title: "Incidents & ChatOps", description: "Alerts, dashboards, and AI summaries." },
  { id: "M4", title: "Self-Healing", description: "Automated runbook execution for remediation." },
  { id: "M5", title: "CI/CD Intelligence", description: "AI pipeline analyzer, one-click deploy/rollback." },
  { id: "M6", title: "Polish & Docs", description: "RBAC, secrets, README, and final reports." },
];

export const TimelineSection: React.FC = () => {
  return (
    <section id="timeline" className="py-20 bg-slate-900/50">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-4xl mx-auto mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">Project Milestones</h2>
          <p className="text-lg text-slate-300">
            Our journey from a basic bootstrap to a fully-featured intelligent DevOps platform.
          </p>
        </div>
        
        <div className="relative wrap overflow-hidden p-10 h-full">
          <div className="absolute border-opacity-20 border-slate-700 h-full border" style={{ left: '50%' }}></div>

          {milestones.map((milestone, index) => (
            <div key={milestone.id} className={`mb-8 flex justify-between items-center w-full ${index % 2 === 0 ? 'flex-row-reverse left-timeline' : 'right-timeline'}`}>
              <div className="order-1 w-5/12"></div>
              <div className="z-20 flex items-center order-1 bg-cyan-500 shadow-xl w-16 h-16 rounded-full">
                <h1 className="mx-auto font-bold text-lg text-white">{milestone.id}</h1>
              </div>
              <div className="order-1 bg-slate-800 rounded-lg shadow-xl w-5/12 px-6 py-4 border border-slate-700">
                <h3 className="mb-3 font-bold text-white text-xl">{milestone.title}</h3>
                <p className="text-sm leading-snug tracking-wide text-slate-400">
                  {milestone.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

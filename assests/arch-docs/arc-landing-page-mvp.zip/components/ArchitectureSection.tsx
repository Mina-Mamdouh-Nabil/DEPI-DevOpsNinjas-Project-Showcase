
import React from 'react';

// Helper component for connecting arrows
const Arrow: React.FC<{ className?: string }> = ({ className = '' }) => (
  <div className={`flex-shrink-0 w-full lg:w-20 h-10 lg:h-auto flex items-center justify-center ${className}`}>
    <svg className="text-cyan-500" width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M4 12H20M20 12L14 6M20 12L14 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  </div>
);

// Helper component for stage containers
const StageBox: React.FC<{ title: string; children: React.ReactNode; className?: string }> = ({ title, children, className }) => (
  <div className={`bg-slate-800/50 p-4 rounded-lg border border-slate-700 w-full md:w-auto md:flex-1 ${className}`}>
    <h4 className="text-lg font-bold text-cyan-400 text-center mb-3">{title}</h4>
    <div className="space-y-2">{children}</div>
  </div>
);

// Helper component for individual items in the flow
const FlowItem: React.FC<{ icon: React.ReactNode; label: string; sublabel?: string }> = ({ icon, label, sublabel }) => (
  <div className="flex items-center gap-3 bg-slate-900/50 p-2 rounded-md border border-slate-600 hover:border-cyan-500 transition-colors">
    <div className="flex-shrink-0 w-8 h-8 flex items-center justify-center text-cyan-300">{icon}</div>
    <div>
        <p className="font-semibold text-white">{label}</p>
        {sublabel && <p className="text-xs text-slate-400">{sublabel}</p>}
    </div>
  </div>
);

// Icons
const GitIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5M7.188 8.812a9.025 9.025 0 0112.131 3.25M3 12a9.025 9.025 0 0110.188-7.188" /></svg>;
const BuildIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" /></svg>;
const TestIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" /></svg>;
const ScanIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 20.417l5.611-1.377A12.02 12.02 0 0012 21.056a12.02 12.02 0 003.389-.54l5.611 1.377a12.02 12.02 0 00-1.38-8.618z" /></svg>;
const DeployIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>;
const MonitorIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>;
const LogsIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>;
const AIIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" /></svg>;
const IncidentIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>;
const HealIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>;
const NotifyIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" /></svg>;


export const ArchitectureSection: React.FC = () => {
  return (
    <section id="architecture" className="py-20 bg-slate-900/50">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-4xl mx-auto mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">Extended DevOps Flow</h2>
          <p className="text-lg text-slate-300">
            From a single commit to an AI-driven, self-healing response, our architecture creates a seamless and intelligent loop.
          </p>
        </div>

        {/* Top Row */}
        <div className="flex flex-col lg:flex-row items-stretch justify-center gap-4">
          <StageBox title="1. Develop & Push">
            <FlowItem icon={<GitIcon/>} label="Git Push" sublabel="Trigger Pipeline"/>
          </StageBox>
          <Arrow className="hidden lg:flex transform-none"/>
          <StageBox title="2. CI Pipeline">
            <FlowItem icon={<BuildIcon/>} label="Build" sublabel="Dockerize Application"/>
            <FlowItem icon={<TestIcon/>} label="Test" sublabel="Unit & Integration"/>
            <FlowItem icon={<ScanIcon/>} label="Security Scan" sublabel="Trivy, OpenSCAP"/>
          </StageBox>
          <Arrow className="hidden lg:flex transform-none"/>
          <StageBox title="3. CD Pipeline">
             <FlowItem icon={<DeployIcon/>} label="Deploy" sublabel="To Kubernetes"/>
             <FlowItem icon={<ScanIcon/>} label="Compliance Scan" sublabel="Post-Deployment Check"/>
          </StageBox>
        </div>
        
        {/* Connector */}
        <div className="flex justify-end my-4 px-0 lg:px-10">
             <Arrow className="transform rotate-90"/>
        </div>

        {/* Bottom Row (Reversed) */}
        <div className="flex flex-col lg:flex-row-reverse items-stretch justify-center gap-4">
           <StageBox title="5. AI Feedback Loop" className="border-blue-500">
             <FlowItem icon={<AIIcon/>} label="AI Analyzer" sublabel="Log & Metric Insights"/>
             <FlowItem icon={<IncidentIcon/>} label="Incident Commander" sublabel="Automated Triage"/>
             <FlowItem icon={<HealIcon/>} label="Self-Healing" sublabel="Trigger Runbooks"/>
             <FlowItem icon={<NotifyIcon/>} label="Notifications" sublabel="Slack & Email Alerts"/>
           </StageBox>
            <Arrow className="hidden lg:flex transform rotate-180"/>
           <StageBox title="4. Operate">
              <FlowItem icon={<MonitorIcon/>} label="Monitoring" sublabel="Prometheus, Grafana"/>
              <FlowItem icon={<LogsIcon/>} label="Logging" sublabel="Loki, ELK"/>
           </StageBox>
        </div>

      </div>
    </section>
  );
};

import React from 'react';

const challenges = [
  { challenge: "Log Overload", mitigation: "Implemented efficient filtering and smart retention policies." },
  { challenge: "Security False Positives", mitigation: "Tuned Sigma/YARA rules and added an AI confidence scoring layer." },
  { challenge: "AI Hallucinations", mitigation: "Raw logs are always displayed alongside AI-generated output for verification." },
  { challenge: "Secrets Management", mitigation: "Integrated with secure backends like HashiCorp Vault or Azure Key Vault." },
  { challenge: "Platform Complexity", mitigation: "Designed with a modular hub architecture for better maintainability." },
  { challenge: "Operational Costs", mitigation: "Started with a self-managed stack (K3s, Ollama) with a clear path to scale to cloud services." },
];

export const ChallengesSection: React.FC = () => {
  return (
    <section id="challenges" className="py-20 bg-slate-900">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-4xl mx-auto mb-12">
          <h2 className="text-4xl font-bold text-white mb-4">Challenges & Mitigations</h2>
          <p className="text-lg text-slate-300">
            Every ambitious project faces hurdles. Here’s how we planned to overcome them.
          </p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {challenges.map(({ challenge, mitigation }) => (
            <div key={challenge} className="bg-slate-800/50 p-6 rounded-lg border border-slate-700">
              <h3 className="text-xl font-bold text-white mb-2">{challenge}</h3>
              <p className="text-slate-400">{mitigation}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

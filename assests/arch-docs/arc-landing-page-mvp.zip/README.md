
<div align="center">
  <a href="#">
    <svg width="80" height="80" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="logoGradient" x1="2" y1="12" x2="22" y2="12" gradientUnits="userSpaceOnUse">
          <stop stopColor="#22d3ee"/>
          <stop offset="1" stopColor="#38bdf8"/>
        </linearGradient>
      </defs>
      <path d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm0 18c-4.411 0-8-3.589-8-8s3.589-8 8-8 8 3.589 8 8-3.589 8-8 8z" fill="url(#logoGradient)"/>
      <path d="M15.414 13.586a2 2 0 1 0-2.828-2.828 2 2 0 0 0 2.828 2.828zM8.586 13.586a2 2 0 1 0-2.828-2.828 2 2 0 0 0 2.828 2.828zM12 17a5 5 0 0 1-5-5h2a3 3 0 0 0 6 0h2a5 5 0 0 1-5 5z" fill="url(#logoGradient)"/>
    </svg>
  </a>
  <h1 align="center">DevOps Command Hub</h1>
  <p align="center">
    A unified command center for intelligent DevOps, from commit to self-healing.
    <br />
    <a href="#about-the-project"><strong>Explore the docs »</strong></a>
    <br />
    <br />
    <a href="https://github.com/AhmedAlhusaini/DEPI-DevOpsNinjas-Project-Showcase">View Demo</a>
    ·
    <a href="https://github.com/AhmedAlhusaini/DEPI-DevOpsNinjas-Project-Showcase/issues">Report Bug</a>
    ·
    <a href="https://github.com/AhmedAlhusaini/DEPI-DevOpsNinjas-Project-Showcase/issues">Request Feature</a>
  </p>
</div>

![React](https://img.shields.io/badge/react-%2320232a.svg?style=for-the-badge&logo=react&logoColor=%2361DAFB)
![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54)
![Kubernetes](https://img.shields.io/badge/kubernetes-%23326ce5.svg?style=for-the-badge&logo=kubernetes&logoColor=white)
![Terraform](https://img.shields.io/badge/terraform-%235835CC.svg?style=for-the-badge&logo=terraform&logoColor=white)
![Ansible](https://img.shields.io/badge/ansible-%231A1918.svg?style=for-the-badge&logo=ansible&logoColor=white)
![Prometheus](https://img.shields.io/badge/Prometheus-E6522C?style=for-the-badge&logo=Prometheus&logoColor=white)

---

## Table of Contents

- [About The Project](#about-the-project)
- [Core Features](#core-features)
- [Tech Stack Roadmap](#tech-stack-roadmap)
- [Architecture: The Extended DevOps Flow](#architecture-the-extended-devops-flow)
- [Project Milestones](#project-milestones)
- [Challenges & Mitigations](#challenges--mitigations)
- [Getting Started](#getting-started)
- [The Team](#the-team)
- [Contributing](#contributing)
- [License](#license)

## About The Project

The **DevOps Command Hub** is a graduation project designed to be a unified platform that covers the full DevOps infinity loop. It integrates the power of **DevOps**, the intelligence of **AI**, and the security of **DevSecOps** into a single, cohesive command center.

Our mission is to provide a comprehensive suite of tools that streamline the entire software development lifecycle, from planning and coding to monitoring and autonomous feedback.

## Core Features

-   **Deploy Page**: CI/CD pipeline visibility, an AI-powered pipeline analyzer, and one-click deploy/rollback capabilities.
-   **Operate Page**: A central change calendar, history of auto-remediation actions, and a library of operational runbooks.
-   **Observe Page**: Service health dependency maps, real-time metrics dashboards, and AI-powered anomaly detection.
-   **Incidents Page**: AI-generated incident timelines, root-cause hypotheses, and auto-created ChatOps channels for collaboration.
-   **Logs Page**: Unified log search across services, AI-powered log explanations, and a DevSecOps lens for security log filtering.
-   **Settings Page**: Manage integrations (GitHub, Slack, Kubernetes), Role-Based Access Control (RBAC), and centralized secrets management.

## Tech Stack Roadmap

This project is built with modern, scalable, and industry-standard technologies to deliver a robust and reliable platform.

-   **Frontend**: React
-   **Backend**: FastAPI (Python)
-   **Workers**: Celery, RQ
-   **IaC**: Terraform, Helm
-   **Runtime**: Docker, Kubernetes (K3s/AKS/EKS/GKE)
-   **Observability**: Prometheus, Grafana, Loki/ELK, Alertmanager, OpenTelemetry
-   **Runbook Engine**: Ansible AWX, Rundeck
-   **AI Layer**: Ollama (local), Azure OpenAI
-   **DevSecOps**: Sigma/YARA, Trivy

## Architecture: The Extended DevOps Flow

Our architecture creates a seamless and intelligent loop, transforming a single commit into an AI-driven, self-healing response.

1.  **Develop & Push**: A `git push` triggers the entire workflow.
2.  **CI Pipeline**: The application is containerized, tested (unit & integration), and scanned for vulnerabilities (Trivy, OpenSCAP).
3.  **CD Pipeline**: The application is deployed to Kubernetes and scanned for post-deployment compliance.
4.  **Operate**: The system is actively monitored using Prometheus and Grafana, with logs aggregated by Loki/ELK.
5.  **AI Feedback Loop**:
    -   **AI Analyzer**: Ingests logs and metrics to provide insights.
    -   **Incident Commander**: Automatically triages alerts and declares incidents.
    -   **Self-Healing**: Triggers remediation runbooks via Ansible AWX or Rundeck.
    -   **Notifications**: Sends alerts and summaries to Slack and email.

## Project Milestones

Our journey from a basic bootstrap to a fully-featured intelligent DevOps platform.

-   **M0: Bootstrap**: Initial repository, K3s cluster, and sample app setup.
-   **M1: Observability Base**: Integrated Prometheus, Grafana, and Loki.
-   **M2: Logs & AI**: Built the log pipeline, AI analyzer, and DevSecOps lens.
-   **M3: Incidents & ChatOps**: Implemented alerts, dashboards, and AI summaries.
-   **M4: Self-Healing**: Enabled automated runbook execution for remediation.
-   **M5: CI/CD Intelligence**: Created the AI pipeline analyzer and one-click deploy/rollback.
-   **M6: Polish & Docs**: Finalized RBAC, secrets management, and documentation.

## Challenges & Mitigations

-   **Log Overload**: Addressed with efficient filtering and smart retention policies.
-   **Security False Positives**: Tuned Sigma/YARA rules and added an AI confidence scoring layer.
-   **AI Hallucinations**: Raw logs are always displayed alongside AI-generated output for verification.
-   **Platform Complexity**: Designed with a modular hub architecture for better maintainability.

## Getting Started

To get a local copy of the frontend up and running, follow these simple steps.

### Prerequisites

-   Node.js (v18 or later)
-   npm, yarn, or pnpm

### Installation

1.  Clone the repo
    ```sh
    git clone https://github.com/AhmedAlhusaini/DEPI-DevOpsNinjas-Project-Showcase.git
    ```
2.  Navigate to the project directory
    ```sh
    cd DEPI-DevOpsNinjas-Project-Showcase
    ```
3.  Install NPM packages
    ```sh
    npm install
    ```
4.  Start the development server
    ```sh
    npm run dev
    ```

## The Team

This project was brought to life by the **DEPI DevOps Ninjas**.

-   **Ahmed Tarek Alhusainy** - _Team Leader_
-   **Lamiaa El-sherif** - _DevOps Engineer_
-   **Mohamed Sherif** - _DevOps Engineer_
-   **Mohamed Reda** - _DevOps Engineer_
-   **Mina Mamdouh** - _DevOps Engineer_

## Contributing

Contributions are what make the open-source community such an amazing place to learn, inspire, and create. Any contributions you make are **greatly appreciated**.

1.  Fork the Project
2.  Create your Feature Branch (`git checkout -b feature/AmazingFeature`)
3.  Commit your Changes (`git commit -m 'Add some AmazingFeature'`)
4.  Push to the Branch (`git push origin feature/AmazingFeature`)
5.  Open a Pull Request

## License

Distributed under the MIT License. See `LICENSE` for more information.

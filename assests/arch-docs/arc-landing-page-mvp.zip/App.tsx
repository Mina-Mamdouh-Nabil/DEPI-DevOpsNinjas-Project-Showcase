
import React from 'react';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { AboutSection } from './components/AboutSection';
import { FeaturesSection } from './components/FeaturesSection';
import { ArchitectureSection } from './components/ArchitectureSection';
import { TechStackSection } from './components/TechStackSection';
import { TimelineSection } from './components/TimelineSection';
import { ChallengesSection } from './components/ChallengesSection';
import { SwotSection } from './components/SwotSection';
import { TeamSection } from './components/TeamSection';
import { FeedbackSection } from './components/FeedbackSection';
import { Footer } from './components/Footer';

const App: React.FC = () => {
  return (
    <div className="bg-slate-900 text-slate-300 font-sans antialiased">
      <Header />
      <main>
        <HeroSection />
        <AboutSection />
        <FeaturesSection />
        <ArchitectureSection />
        <TechStackSection />
        <TimelineSection />
        <ChallengesSection />
        <SwotSection />
        <TeamSection />
        <FeedbackSection />
      </main>
      <Footer />
    </div>
  );
};

export default App;